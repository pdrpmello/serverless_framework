# Python portfolio
 Portfolio with Junior Python Projects.